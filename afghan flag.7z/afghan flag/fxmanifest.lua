fx_version "bodacious"

game 'gta5'

this_is_a_map "yes"

--Stop the War--
--Open Dialog--
--This is not the 20th century. The world is watching--
--Stay Strong Ukraine--
